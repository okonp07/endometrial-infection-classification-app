Endometrial Infection Classification App

Bundle contents:
- 20 demo images from the held-out test split
- neutral scan filenames with no class labels in the archive
- randomized file order for more natural blind testing

Intended use:
These images are provided so users can test the deployed application without sourcing their own scans.
The archive is intentionally unlabeled so filename cues do not hint at the expected model output.